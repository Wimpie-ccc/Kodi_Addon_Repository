# script.service.bluray_iso_utils
Kodi addon - Used to make all videos in a bluray iso file available and scrapeable to Kodi

More info in the Wiki

Support at the kodi forums: http://forum.kodi.tv/showthread.php?tid=280247
